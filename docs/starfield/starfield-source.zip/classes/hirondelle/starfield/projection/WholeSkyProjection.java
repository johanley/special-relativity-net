package hirondelle.starfield.projection;

/**
 Template base class for whole-sky projections.
  
 <P>For whole-sky projections, it's convenient to transform to numbers that can be plugged 
 directly into typical formulas for map projections, that use latitude and longitude (positive east of the prime meridian).
  
 <P>In essence, this effects a 90 degree rotation, changing from a pole-on view using (r,theta,phi) 
  and having the z-axis into the screen, to a pole-up view, with latitude up-down, and longitude left-right. 
*/
abstract class WholeSkyProjection implements Projection {

  @Override public final Coords project(double aThetaprime, double aPhi, double aScale, Coords aCenter) {
    double  x=aPhi-1.5*Math.PI;
    double latitudeVal=Math.asin(Math.sin(aThetaprime)*Math.cos(x)); //-pi/2..+pi/2
    double longitudeVal=Math.atan2(Math.sin(aThetaprime)*Math.sin(x),Math.cos(aThetaprime)); //-pi..+pi
    return projectWithLatLong(-latitudeVal, longitudeVal, aScale, aCenter);
  }

  /** 
   Use a projection formula expressed in latitude and longitude. See class comment.
  */
  abstract Coords projectWithLatLong(double aLatitude, double aLongitude, double aScale, Coords aCenter);
}
