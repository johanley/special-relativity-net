package hirondelle.starfield.projection;

/** 
 Whole sky projection, with boundary as a 2:1 ellipse.
 <P>Reference: <a href='http://en.wikipedia.org/wiki/Hammer_projection'>wikipedia</a>. 
*/
final class HammerProjection  extends WholeSkyProjection {

  @Override public Coords projectWithLatLong(double aLat, double aLong, double aScale, Coords aCenter) {
    Coords result = new Coords();
    double deltax = 1.2 * aScale * 2 * Math.sqrt(2) * Math.cos(aLat) * Math.sin(aLong/2.0D);
    double deltay = 1.2 * aScale * Math.sqrt(2) * Math.sin(aLat);
    result.X = aCenter.X + deltax;
    result.Y = aCenter.Y + deltay;
    return result;
  }

}