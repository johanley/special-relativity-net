package hirondelle.starfield.projection;

/** 
 Half-sky projection, equal areas.
 <P>This is the projection used in the 1979 paper by McKinley and Doherty, where 
  the projection was not referred to with a specific name.  
*/
final class MckinleyProjection implements Projection {

  @Override public Coords project(double aThetaprime, double aPhi, double aScale, Coords aCenter) {
    Coords result = new Coords();
    double r = Math.sqrt(1-Math.cos(aThetaprime));
    double deltax = aScale * r * Math.cos(aPhi);
    double deltay = aScale * r * Math.sin(aPhi);
    result.X = aCenter.X + deltax;
    result.Y = aCenter.Y + deltay;
    return result;
  }
}
