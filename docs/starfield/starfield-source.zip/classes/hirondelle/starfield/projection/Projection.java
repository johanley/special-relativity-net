package hirondelle.starfield.projection;

/** 
 Project a star's location on the celestial sphere onto the plane of an image.
 
 <P>Some projections may apply to the whole sky, while some may apply to half the sky.
 The half-sky projections correspond better to what can be seen by a human eye. 
 In addition, at very high speeds, almost all stars will be concentrated towards the direction of motion, because 
 of aberration; in this case, the use of a whole-sky projection is probably not the best choice. 
*/
public interface Projection {
  
  /**
   Return the coordinates of the star, ready for rendering on an image context.
   
   <P>The two arguments correspond to two angles on the celestial sphere.
   These two angles can take a different meaning according to context.
   For example, in the simple case of stereographic projection centered on the North Celestial Pole,
   the two arguments correspond to the (aberrated) zenith angle from the Pole and the right ascension, respectively.  
   For the full-sky projections, the two arguments correspond more to latitude and longitude 
   (declination and right ascension), respectively.
  */
  Coords project(double aAngle1, double aAngle2, double aScale, Coords aCenter);
}
