package hirondelle.starfield.projection;

import hirondelle.starfield.util.Util;

/**
  Whole sky projection with many variations, according to the value of the 'standard latitude'.
  <P>Reference: <a href='http://en.wikipedia.org/wiki/Cylindrical_equal-area_projection'>wikipedia</a>.
*/
final class EqualAreaCylindricalProjection extends WholeSkyProjection {

  /**
   Constructor.
   @param aStandardLat in degrees
  */
  EqualAreaCylindricalProjection(double aStandardLat) {
    fStandardLat = Util.radians(aStandardLat);
  }
  
  @Override  public Coords projectWithLatLong(double aLat, double aLong, double aScale, Coords aCenter) {
    Coords result = new Coords();
    double deltax = aScale * aLong * Math.cos(fStandardLat);
    double deltay = aScale * Math.sin(aLat)/Math.cos(fStandardLat);
    result.X = aCenter.X + deltax;
    result.Y = aCenter.Y + deltay;
    return result;
  }

  private double fStandardLat;
}
