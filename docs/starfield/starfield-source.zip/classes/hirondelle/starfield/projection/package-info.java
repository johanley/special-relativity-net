/** 
 Various projections of the celestial sphere onto a plane.
 The stereographic and McKinley projections are good defaults; they are the 
 half-sky projections. 
*/
package hirondelle.starfield.projection;