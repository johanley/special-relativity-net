package hirondelle.starfield.projection;

/** 
 Half-sky projection, preserves small circles on the celestial sphere.
*/
final class StereoscopicProjection implements Projection {
  
  @Override public Coords project(double aThetaprime, double aPhi, double aScale, Coords aCenter) {
    Coords result = new Coords();
    double r = 0;
    if (aThetaprime > 0){
      //avoid division by 0 when thetaprime is 0
      r = (1-Math.cos(aThetaprime))/Math.sin(aThetaprime);
    }
    double deltax = aScale * r * Math.cos(aPhi);
    double deltay = aScale * r * Math.sin(aPhi);
    result.X = aCenter.X + deltax;
    result.Y = aCenter.Y + deltay;
    return result;
  }

}
