package hirondelle.starfield.projection;

/** 
 Whole sky projection; mathematically, this one has the simplest implementation.
 <P>Reference: <a href='http://en.wikipedia.org/wiki/Equirectangular_projection'>wikipedia</a>. 
*/
final class EquiRectangularProjection extends WholeSkyProjection {

  /** See class comment. */
  @Override Coords projectWithLatLong(double aLatitude, double aLongitude, double aScale, Coords aCenter) {
    Coords result = new Coords();
    double deltax = aScale * aLongitude;
    double deltay = aScale * aLatitude;
    result.X = aCenter.X + deltax;
    result.Y = aCenter.Y + deltay;
    return result;
  }
  
}
