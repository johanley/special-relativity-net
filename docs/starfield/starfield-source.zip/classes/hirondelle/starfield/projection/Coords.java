package hirondelle.starfield.projection;

/**  Struct to hold image pixel coords for a projected star location. */
public final class Coords {

  Coords(){ }

  public Coords(double x, double y){
    X = x;
    Y = y;
  }

  public double X;
  public double Y;
  
  /** Intended for debugging. */
  @Override public String toString(){
    return "X:"+X + " Y:"+ Y;
  }
}
