package hirondelle.starfield.projection;

/** 
  Whole sky projection, variation of {@link EqualAreaCylindricalProjection}.
  Uses a standard latitude of 30 degrees. 
*/
final class BehrmannProjection implements Projection {

  BehrmannProjection() {
    fBaseProjection = new EqualAreaCylindricalProjection(STANDARD_LATITUDE);
  }
  
  @Override public Coords project(double thetaprime, double phi, double aScale, Coords aCenter) {
    return fBaseProjection.project(thetaprime, phi, aScale * 1.3, aCenter);
  }
  
  private EqualAreaCylindricalProjection fBaseProjection;
  private static final double STANDARD_LATITUDE = 30.0;
}
