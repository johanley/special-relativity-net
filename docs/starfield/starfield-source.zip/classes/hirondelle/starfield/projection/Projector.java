package hirondelle.starfield.projection;

/** Enumeration to indicate the desired {@link Projection} to be used in making the starfield image. */
public enum Projector {
  
  STEREOSCOPIC(true, new StereoscopicProjection()),
  MCKINLEY(true, new MckinleyProjection()),
  EQUIRECTANGULAR(false, new EquiRectangularProjection()),
  BEHRMANN(false, new BehrmannProjection()),
  HAMMER(false, new HammerProjection());

  /** 
   Return <tt>true</tt> only if the projection will present a half-sky view, and not a whole-sky view.
   Stereoscopic and McKinley are the half-sky views. 
  */
  public boolean isHalfSky(){
    return fIsHalfSky;
  }
  
  /** Return the corresponding implementation of {@link Projection}. */
  public Projection getProjection() { return fProjection; }
  
  private Projector(boolean aIsHalfSky, Projection aProjection){
    fIsHalfSky = aIsHalfSky;
    fProjection = aProjection;
  }
  
  private boolean fIsHalfSky;
  private Projection fProjection;
  
}
