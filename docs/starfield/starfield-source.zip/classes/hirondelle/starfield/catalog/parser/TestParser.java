package hirondelle.starfield.catalog.parser;

import hirondelle.starfield.physics.Star;

/** 
Parse an artificial test record. Intended for testing only.
The idea is that you create simple data sets by hand to test with.

<P>This class uses the following <em>ad hoc</em> format for each line of test data: 
<pre>
Byte 1..2: RA-H
Byte 3     space
Byte 4..5: RA-M
Byte 6     space
Byte 7..8: RA-S, no fraction 
Byte 9     space
Byte 10..12: Deg, with leading minus sign 
Byte 13     space
Byte 14..15: Deg-min 
Byte 16     space
Byte 17..18: Deg-sec, no fraction
Byte 19     space
Byte 20..24: Magnitude; example: '-6.70'
Byte 25     space
Byte 26: Spectral Type 
</pre>

<P>Comments: any lines starting with '-' are ignored. This lets you insert comment lines directly in the data, 
if desired.
*/
final class TestParser  implements RecordParser  {

  /** See class comment.  */
  @Override public Star parse(String aLine) {
    Star result = null;
    if (! aLine.startsWith("-")){
      result = new Star();
      Chomper chomper = new Chomper(aLine);
      String spectralClass = chomper.forText(26);
      result.Temperature = Star.spectralTypeToTemperature(spectralClass); 
      result.RightAscension = chomper.forRightAscension(1,2,4,5,7,8);
      result.Declination = chomper.forDeclination(10,11,12,14,15,17,18);
      result.Magnitude = chomper.forMagnitude(20,24);
    }
    return result;
  }

}
