package hirondelle.starfield.catalog.parser;

import hirondelle.starfield.physics.Star;
import hirondelle.starfield.util.Util;

/** 
Parse a record from the <a href='http://cdsarc.u-strasbg.fr/viz-bin/Cat?I/259'>Tycho 2 Catalog</a>.
Uses epoch J2000. This catalog is very large, and has over 2 million stars.

<P>Record details:
<pre>
Byte 14: X indicates that the position is missing
Byte 153..164: RA in degrees 1234.12345678
Byte 166..177: Dec in degrees 1234.12345678, leading sign
Byte 111..116: BTMag 123.123
Byte 124..129: VTMag
</pre>

<P>There are two positions given in this catalog. Here, We take the one that is always present.

<P>Approximate Johnson photometry; can derive V and color B-V, from VT, BT using:
<pre>
V=VT-0.090*(BT-VT)
B-V=0.850*(BT-VT)
</pre>
Internally, B-V is mapped to a representative approximate temperature. 

<P>Records discarded by this parser:
<ul>
 <li>those that are missing either BTMag or VTMag
</ul>
*/
final class Tycho2Catalog implements RecordParser {

  /** See class comment.  */
  public Star parse(String aLine) {
    Star result = null;
    //Util.logVerbose(aLine);
    Chomper chomper = new Chomper(aLine);
    if ( chomper.isMissing(124,129) || chomper.isMissing(111,116)){
      Util.logVerbose("Skipping record. Missing at least one of VTMag, BTMag.");
    }
    else {
      //no more reasons left for skipping a record
      result = new Star();
      
      Double vtmag = chomper.forDouble(124,129);
      Double btmag = chomper.forDouble(111,116);
      
      double ra = chomper.forDouble(153,164);
      result.RightAscension = Util.radians(ra);
      double dec = chomper.forDouble(166,177);
      result.Declination = Util.radians(dec);
      
      result.Magnitude = vtmag - 0.090D * (btmag - vtmag);
      double colorIndex = 0.850D * (btmag-vtmag);
      result.Temperature = Star.colorIndexToTemperature(colorIndex); 
    }
    return result;
  }
  
}
