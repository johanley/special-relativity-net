package hirondelle.starfield.catalog.parser;

/** 
 Enumeration of all implemented star catalogs, along with their corresponding 
 {@link RecordParser} implementations. 
*/
public enum Catalog {

    YALE_BRIGHT_STAR_CATALOG(new YaleBrightStarCatalog()),
    HENRY_DRAPER_CATALOG(new HenryDraperCatalog()),
    TYCHO2_CATALOG(new Tycho2Catalog()),
    TEST_CATALOG(new TestParser());
    
    /** Return the object which can parse a catalog record into the required data. */
    public RecordParser getRecordParser(){  return fRecordParser;  }
    
    private RecordParser fRecordParser;
    private Catalog(RecordParser aParser){
      fRecordParser = aParser;
    }
}
