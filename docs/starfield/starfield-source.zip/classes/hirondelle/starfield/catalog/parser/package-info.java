/**
  Parse a single line of a catalog record into the data needed for the starfield calculation.
*/
package hirondelle.starfield.catalog.parser;