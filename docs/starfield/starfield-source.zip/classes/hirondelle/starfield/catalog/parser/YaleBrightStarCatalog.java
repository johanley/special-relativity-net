package hirondelle.starfield.catalog.parser;

import hirondelle.starfield.physics.Star;
import hirondelle.starfield.util.Util;

/** 
  Parse a record from the <a href='http://cdsarc.u-strasbg.fr/viz-bin/Cat?V/50'>Yale Bright Star Catalog</a>.
  Uses epoch J2000, to mag 6.5 (mostly). This catalog is small, having about 9,000 stars.
  This catalog is a good choice when starting out, since the application runs so quickly when using such a small 
  amount of data.

 <P>Record details:
<pre>
Byte 76..77: RA-H
Byte 78..79: RA-M
Byte 80..83: RA-S to 0.1, includes decimal point. Example '09.9': 
Byte 84:     Sign of declination
Byte 85..86: Dec-deg
Byte 87..88: Dec-min
Byte 89..90: Dec-sec
Byte 103..107: Visual Mag. Example '6.70';  two decimals, with decimal point, 
                     with leading '-' sign for the brightest stars
Byte 128-147: Spectral Type. Take byte 130 only.
</pre>

<P>Records discarded by this parser:
<ul>
   <li>those with spectral type starting with S,C,p,N,W
   <li>those with spectral type blank (items that should not have been in the catalog to begin with)
</ul>
*/
final class YaleBrightStarCatalog implements RecordParser {

  /** See class comment.  */
  @Override public Star parse(String aLine) {
    Star result = null;
    Chomper chomper = new Chomper(aLine);
    String spectralClass = chomper.forText(130);
    if (! Util.textHasContent(spectralClass) ){
      Util.logVerbose("Skipping record. Missing spectral class.");
    }
    else if (spectralClass.startsWith("S") || spectralClass.startsWith("C") || spectralClass.startsWith("p") || spectralClass.startsWith("W") || spectralClass.startsWith("N")){
      Util.logVerbose("Skipping record. Not in the set of expected spectral classes: " + spectralClass);
    }
    else {
      //no more reasons left for skipping a record
      result = new Star();
      result.Temperature = Star.spectralTypeToTemperature(spectralClass.substring(0,1)); //first letter only
      result.RightAscension = chomper.forRightAscension(76,77,78,79,80,83);
      result.Declination = chomper.forDeclination(84,85,86,87,88,89,90);
      result.Magnitude = chomper.forMagnitude(103,107);
    }
    return result;
  }
  
}
