package hirondelle.starfield.catalog.parser;

import hirondelle.starfield.physics.Star;

/** 
  <b>Create a Star object from a single record in a star catalog.</b>
  Assumes that a single line in the file corresponds to a single star. 
*/
public interface RecordParser {

  /** 
   Parse a single line from a star catalog into the parts needed for the starfield calculation.
   In many cases the data will have to be massaged a bit to get the exact data needed by 
   the Star class.
   
   <P><b>Parsers must return null if the line cannot be parsed into a Star object.</b>
   This can happen when the data is wonky for some reason. For example, the Yale Bright Star Catalog has a number of 
   entries that are essentially blank. 
   
   <P>All angles must be converted to radians.
   Be careful of the sign of the declination.  
  */
  Star parse(String aLine);
  
}
