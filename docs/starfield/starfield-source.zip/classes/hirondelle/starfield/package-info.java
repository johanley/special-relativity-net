/** <b>Launch point</b> for the command line version of the application. */
package hirondelle.starfield;