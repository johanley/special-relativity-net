package hirondelle.starfield.util;

/** Constants of general utility. */
public final class Consts {
  
  /** Newline separator. */
  public static final String NL = System.getProperty("line.separator");

  public static final String APP_NAME = "Relativistic Starfield 1.0.0";

  private Consts(){}
  
}
