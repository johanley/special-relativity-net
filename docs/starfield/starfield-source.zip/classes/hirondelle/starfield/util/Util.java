package hirondelle.starfield.util;

/** Utility methods. */
public final class Util {

  /** 
   Log to stdout.
   <P>This tool doesn't use Java's logging classes, simply to make it easier to run 
   for those not familiar with Java's logging mechanism. In general, this tool's logging needs 
   are minimal. 
 */
  public static final void log(Object aMsg){
    System.out.println(aMsg.toString());
  }
  
  /** 
   Print to stdout only if a System property named 'verbose' exists.
   (The value of the property itself is not used.) 
 */
  public static final void logVerbose(Object aMsg){
    if ( textHasContent(System.getProperty("verbose")) ){
      System.out.println(aMsg.toString());
    }
  }
  
  /** Log to stderr. */
  public static final void err(Object aMsg){
    System.err.println(aMsg.toString());
  }
  
  /**
   Return <tt>true</tt> only if <tt>aText</tt> is not null,
   and if its raw <tt>String</tt> is not empty after trimming. (Trimming removes both
   leading/trailing whitespace and ASCII control characters. See {@link String#trim()}.)
    
   @param aText possibly-null.
  */
  public static boolean textHasContent(String aText){
    return (aText != null) && (aText.trim().length() > 0);
  }
  
  /** Put the given text in single quotes. Intended for logging variable data. */
  public static String quote(String aText){
    return "'" + aText + "'";
  }
  
  /** Convert degrees to radians. */
  public static double radians(double aDegrees){
    return aDegrees * Math.PI/180.0D; //avoid integer division
  }
  
  /**
  Return <tt>true</tt> only if <tt>aNumber</tt> is in the range 
  <tt>aLow..aHigh</tt> (inclusive).
 
  <P> For checking argument validity, {@link Args#checkForRange} should 
  be used instead of this method.
 
  @param aLow less than or equal to <tt>aHigh</tt>.
 */
 static public boolean isInRange( int aNumber, int aLow, int aHigh ){
   if (aLow > aHigh) {
     throw new IllegalArgumentException("Low is greater than High.");
   }
   return (aLow <= aNumber && aNumber <= aHigh);
 }
  
  private Util(){}
  
}