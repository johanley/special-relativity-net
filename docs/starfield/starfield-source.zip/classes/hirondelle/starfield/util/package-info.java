/** Minor utilities. */
package hirondelle.starfield.util;