/** <b>Launch point</b> for the graphical (GUI) version of the application. */
package hirondelle.starfield.gui;