package hirondelle.starfield.gui;

import hirondelle.starfield.util.Util;

import java.awt.Font;
import java.util.Enumeration;

import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

/** 
 <b>Launch point</b> for the graphical (GUI) version of the application.
*/ 
public final class Launch {
  
  /** 
   Run the graphical application.

  <P>Performs the following :
   <ul>
    <li>configure a custom {@link ExceptionHandler} for uncaught exceptions
    <li>use the native look and feel, natural to the runtime operating system
    <li>sets the font for the application (12-point Verdana)
   </ul>
 */
  public static void main(String... aArgs) {
    useCustomExceptionHandler();    
    useNativeLookAndFeel();
    setApplicationFont();
    Screen screen = new Screen();
    screen.buildAndShow();
  }

  // PRIVATE 
  
  /**   See {@link ExceptionHandler}.    */
  private static void useCustomExceptionHandler(){
    Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler());
  }

  /**
  Use the look which is usually used on the current operating system.
  
  <P>For example, on a Windows machine, use a Windows look and feel.
  If you are using a non-default look and feel, then you should set it first thing.
  For more info, see the 
  <a href='http://java.sun.com/docs/books/tutorial/uiswing/lookandfeel/plaf.html#available'>Swing Tutorial</a>
  
  <P>Warning: on Windows, the native look & feel displays accelerator keys only when ALT key is held down. 
  Otherwise, they are not displayed!
*/
  private static void useNativeLookAndFeel() {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch(Throwable ex){
      Util.log("Cannot set the look and feel.");
    }
  }
  
  private static void setApplicationFont() {
    FontUIResource fontResource = new FontUIResource("Verdana",Font.PLAIN,12);
    Enumeration keys = UIManager.getDefaults().keys();
    while (keys.hasMoreElements()) {
      Object key = keys.nextElement();
      Object value = UIManager.get (key);
      if (value instanceof FontUIResource) {
        UIManager.put (key, fontResource);
      }
    }
  }
  
}
