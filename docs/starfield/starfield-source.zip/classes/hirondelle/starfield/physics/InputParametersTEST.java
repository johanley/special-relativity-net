package hirondelle.starfield.physics;

import junit.framework.TestCase;

public final class InputParametersTEST  extends TestCase {
  
  /** Run the test cases.  */
  public static void main(String args[]) {
    String[] testCaseName = { InputParametersTEST.class.getName() };
    junit.textui.TestRunner.main(testCaseName);
  }

  public InputParametersTEST(String aName) {
    super(aName);
  }
  
  // TEST CASES
  
  public void testConstructorFail(){
    testCtorFail("-0.0001", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorFail("-1", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorFail("1", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorFail("1.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorFail("1.00001", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorFail("a", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    
    testCtorFail("0.0", "a", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );

    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "X_YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );

    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "X_STEREOSCOPIC", "800", "1", "0", "90", "0" );

    testCtorFail("0.0", "5.0", "C:\\astro-cat\\not-exist", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data\\leo_near_galactic_pole.txt", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );

    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "a", "1", "0", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "-1", "1", "0", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "0", "1", "0", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "12.3", "1", "0", "90", "0" );
    
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "0", "0", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "-1", "0", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "15.3", "0", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "a", "0", "90", "0" );
    
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "-0.0001", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "-1", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "360.0001", "90", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "a", "90", "0" );

    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "-90.0001", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90.0001", "0" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "a", "0" );

    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "-0.00001" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "360.00001" );
    testCtorFail("0.0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "aoeu" );
  }
  
  public void testConstructorSucceed(){
    testCtorSucceed("0", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorSucceed("0.000001", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorSucceed("0.999999999999999", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    //this test actually FAILS:
    //testCtorSucceed("0.99999999999999999", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorSucceed("0.5", "5.5", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorSucceed("0.5", "6.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorSucceed("0.5", "0.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorSucceed("0.5", "-0.0001", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    testCtorSucceed("0.5", "10", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "1", "0", "90", "0" );
    
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "100", "1", "0", "90", "0" );
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "10000", "1", "0", "90", "0" );
    
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "0", "90", "0" );
    
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "0.00001", "90", "0" );
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "359.99999", "90", "0" );
    
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "0", "0", "0" );
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "0", "0.00001", "0" );
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "0", "-90", "0" );
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "0", "90", "0" );
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "0", "-0.00001", "0" );
    
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "0", "90", "0.0001" );
    testCtorSucceed("0.5", "5.0", "C:\\astro-cat\\test-data", "YALE_BRIGHT_STAR_CATALOG", "C:\\TEMP\\test.png", "STEREOSCOPIC", "800", "10", "0", "90", "359.99999" );
  }
  
  // PRIVATE
  
  /** There must be a single reason for the failure. */
  private void testCtorFail(
    String aBeta, String aLimitingMag, String aCatalogDir, String aCatalog, String aOutputFile, String aProjector,
    String aImageSize, String aMagnification, String aDirectionRA, String aDirectionDec, String aRotation
  ){
    try {
      InputParameters input = new InputParameters(aBeta, aLimitingMag, aCatalogDir, aCatalog, aOutputFile, aProjector, aImageSize, aMagnification, aDirectionRA, aDirectionDec, aRotation);
      fail("Unexpected successful construction of InputParameters.");
    }
    catch (InputParameterException ex){
      //expected
      if (ex.getErrors().size() != 1){
        fail("More than 1 error: " + ex.getErrors());
      }
    }
  }
  
  private void testCtorSucceed(
    String aBeta, String aLimitingMag, String aCatalogDir, String aCatalog, String aOutputFile, String aProjector,
    String aImageSize, String aMagnification, String aDirectionRA, String aDirectionDec, String aRotation
  ){
    try {
      InputParameters input = new InputParameters(aBeta, aLimitingMag, aCatalogDir, aCatalog, aOutputFile, aProjector, aImageSize, aMagnification, aDirectionRA, aDirectionDec, aRotation);
    }
    catch (InputParameterException ex){
      fail("Unexpected failure to construct InputParameters." + ex.getErrors());
    }
  }

}