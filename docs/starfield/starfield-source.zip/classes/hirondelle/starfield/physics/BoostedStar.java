package hirondelle.starfield.physics;

import hirondelle.starfield.util.Consts;

/**
  Struct to carry the results of a boost calculation for a star.
*/
final class BoostedStar {

  /** The angle from direction of motion, after the boost. */ 
  double ThetaPrime;
  /** The apparent magnitude of the star after the boost. */
  double Magnitude;
  /** The apparent blackbody surface temperature of the star, after the boost. */
  double Temperature;

  /** Coordinate for rendering the star on an image. */ 
  double X;
  /** Coordinate for rendering the star on an image. */ 
  double Y;

  /** For debugging only. */
  @Override public String toString(){
    StringBuilder result = new StringBuilder();
    result.append("Boosted Star ThetaPrime: " + ThetaPrime);
    result.append(" Mag: " + Magnitude);
    result.append(" Temp: " + Temperature);
    result.append(" X: " + X);
    result.append(" Y: " + Y + Consts.NL);
    return result.toString();
  }
  
}