package hirondelle.starfield.physics;

import static hirondelle.starfield.util.Consts.NL;

/** 
 Struct for high-level statistics regarding the starfield.
*/
public final class StarfieldStats {
  
  /** The total number of stars extracted successfully from the star catalog, both above and below the limiting magnitude. */
  public int NumStarsInSimulation;
  
  /** Occasionally, some catalog records can't be used, for various reasons. */
  public int NumRecordsRejected;
  
  /** Number of stars that are brighter than the limiting magnitude. */
  public int NumStarsVisible;
  
  /** The brightness index of all the visible stars; a 0-magnitude star contributes a brightness value of 1. */
  public double BrightnessIndex;

  /** Return the basic stats as a single string. */
  @Override public String toString(){
    StringBuilder result = new StringBuilder();
    result.append("Number of rejected catalog records: " + NumRecordsRejected + NL);
    result.append("Number of stars in simulation: " + NumStarsInSimulation + NL);
    result.append("Number of visible stars: " + NumStarsVisible + NL);
    result.append("Brightness index: " + BrightnessIndex + NL);
    return result.toString();
  }
  
}
