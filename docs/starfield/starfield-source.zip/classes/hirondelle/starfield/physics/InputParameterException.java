package hirondelle.starfield.physics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 Checked exception thrown when an error in user input is detected.
*/
public final class InputParameterException extends Exception {
  
  InputParameterException(){ 
    super();
  }
  
  /** Add a single error message. This method is called once for each error. */
  void add(String aError){
    fErrors.add(aError);
  }

  /** Return <tt>true</tt> only if there's 1 or more errors. */
  boolean hasError(){
    return ! fErrors.isEmpty();
  }

  /** Return all the error messages. */
  public List<String> getErrors(){
    return Collections.unmodifiableList(fErrors);
  }
  
  private List<String> fErrors = new ArrayList<>();

}
