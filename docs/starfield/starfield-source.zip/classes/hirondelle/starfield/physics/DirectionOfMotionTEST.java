package hirondelle.starfield.physics;

import hirondelle.starfield.util.Util;
import junit.framework.TestCase;

public final class DirectionOfMotionTEST extends TestCase {
  
  /** Run the test cases.  */
  public static void main(String args[]) {
    String[] testCaseName = { DirectionOfMotionTEST.class.getName() };
    junit.textui.TestRunner.main(testCaseName);
  }

  public DirectionOfMotionTEST(String aName) {
    super(aName);
  }
  
  // TEST CASES

  public void testIsDefault(){
    testIsDef(0, 90, 0);
    testIsDef(0, 90.000001, 0);
    testIsDef(0.0, 90, 0);
    testIsDef(0.0, 90, 0.0);
    //this fails
    //testIsDef(0, 90.00001, 0);
  }

  public void testIsNotDefault(){
    testIsNotDef(0, 89, 0);
    testIsNotDef(0.00001, 90, 0);
    testIsNotDef(0, 90, 0.00001);
    testIsNotDef(0, 90.00001, 0);
    //this fails:
    //testIsNotDef(0, 90.000001, 0);
  }
  
  //  PRIVATE 
  private void testIsDef(double aRA, double aDec, double aPhi){
    DirectionOfMotion motion = new DirectionOfMotion(Util.radians(aRA), Util.radians(aDec), Util.radians(aPhi));
    boolean isNotDef = motion.isNotDefault();
    assertTrue(!isNotDef);
  }
  
  private void testIsNotDef(double aRA, double aDec, double aPhi){
    DirectionOfMotion motion = new DirectionOfMotion(Util.radians(aRA), Util.radians(aDec), Util.radians(aPhi));
    boolean isNotDef = motion.isNotDefault();
    assertTrue(isNotDef);
  }
  
}
