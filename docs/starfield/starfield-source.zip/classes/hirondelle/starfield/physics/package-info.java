/** Core data and calculations. */
package hirondelle.starfield.physics;