package hirondelle.starfield;

import hirondelle.starfield.physics.InputParameterException;
import hirondelle.starfield.physics.InputParameters;
import hirondelle.starfield.physics.Starfield;
import hirondelle.starfield.physics.StarfieldStats;
import hirondelle.starfield.util.Consts;
import hirondelle.starfield.util.Util;

import java.awt.Toolkit;

/**
 <b>Launch point</b> for the tool.
 This class is uses the command line only, with no graphical interface.
 
 <P>Example command line (for clarity, each part is placed on a separate line here):
 <pre>
...starfield\classes&gt;java 
-cp . 
-Xmx512m
hirondelle.starfield.Main 
0.993 
5.0 
C:\astro-cat\yale-bright-star-cat 
YALE_BRIGHT_STAR_CATALOG
C:\temp\test.png
STEREOSCOPIC
800
1
0
90
0
</pre>

<P>The 11 arguments passed to the Main class itself are passed in order to the {@link InputParameters} class.
If no problem is found with the input, then {@link Starfield} is used to accomplish the desired task.

<P><em>You can edit this class directly</em> to suit your own needs.
*/
public final class Main {

  /**
    Run this application from the command line. 
    Calls {@link Starfield#calculate()} with given arguments passed on the command line.
    See the class comment for an example, and an explanation of the required arguments. 
  */
  public static void main(String... aArgs){
    long start = System.currentTimeMillis();
    Util.log("Launching..." + Consts.NL);
    Util.log("JRE total memory: " + Runtime.getRuntime().totalMemory());
    Util.log("JRE free memory: " + Runtime.getRuntime().freeMemory() + Consts.NL);
    InputParameters input = null; 
    try {
      input = new InputParameters(aArgs[0],aArgs[1], aArgs[2], aArgs[3], aArgs[4], aArgs[5], aArgs[6], aArgs[7],  aArgs[8],  aArgs[9],  aArgs[10]);
      Util.log(input);
      calculateStarfield(input);
    }
    catch(InputParameterException ex){
      for(String error : ex.getErrors()){
        Util.log(error+Consts.NL);
      }
      Util.log("Error: Aborting, arguments not correct. Please see javadoc for more information.");
    }
    long end = System.currentTimeMillis();
    Util.log(Consts.NL + "Done. Elapsed time: " + (end-start)/1000.0D + " seconds.");
    Toolkit.getDefaultToolkit().beep();
  }

  // PRIVATE 
  
  /** 
   Calculate a result for the given beta and limiting magnitude.
   Calls {@link Starfield#calculate()}.
  */
  private static void calculateStarfield(InputParameters aInput){
      Starfield starfield = new Starfield(aInput);
      //output of stats to the command line, PLUS generate an image of the stars
      StarfieldStats stats = starfield.calculate();
      //simple output of stats to the command line, with no image:
      //StarfieldStats stats = starfield.calculate();
      Util.log(stats.toString());
  }
}